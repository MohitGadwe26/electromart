package com.electromart.product.repository;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.electromart.product.Product;

public interface ProductRepository extends JpaRepository<Product, Long>,JpaSpecificationExecutor<Product> {

    List<Product> findByActiveTrue();

    // Add method to find featured products
    List<Product> findByFeaturedTrueAndActiveTrue();

    long countByCategoryId(Long categoryId);

    long countByBrandId(Long brandId);

    List<Product> findByCategoryId(Long categoryId);

    List<Product> findByPriceBetween(BigDecimal min, BigDecimal max);

    List<Product> findByBrand_NameIgnoreCase(String brand);
}

