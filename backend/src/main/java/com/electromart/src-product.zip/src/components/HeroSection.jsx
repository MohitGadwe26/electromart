// src/components/HeroSection.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import bannerService from '../api/bannerService';
import categoryService from '../api/categoryService';
import productService from '../api/productService';
import styles from './HeroSection.module.css';

const HeroSection = () => {
  const navigate = useNavigate();
  const [banners, setBanners] = useState([]);
  const [productCards, setProductCards] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Static product cards data (can be moved to config later)
  // This is temporary until you have backend API for cards
  const staticProductCards = [
    {
      id: 1,
      cardText: "Up to 50% off | Baby care & toys | Amazon Brands",
      categoryLink: "/products/filter?categoryId=18&maxPrice=2000",
      items: [
        { id: 1, productName: "Baby Care Set", imageUrl: "/images/products/baby-care-1.jpg", offerText: "Starting ₹199", redirectUrl: "/product/1" },
        { id: 2, productName: "Baby Wipes", imageUrl: "/images/products/baby-wipes.jpg", offerText: "Starting ₹99", redirectUrl: "/product/2" },
        { id: 3, productName: "Toy Car", imageUrl: "/images/products/toy-car.jpg", offerText: "Starting ₹299", redirectUrl: "/product/3" },
        { id: 4, productName: "Diapers Pack", imageUrl: "/images/products/diapers.jpg", offerText: "Starting ₹399", redirectUrl: "/product/4" }
      ]
    },
    {
      id: 2,
      cardText: "Up to 50% off | Baby diapers & wipes",
      categoryLink: "/products/filter?categoryId=29&maxPrice=1500",
      items: [
        { id: 5, productName: "Pampers Diapers", imageUrl: "/images/products/pampers.jpg", offerText: "Starting ₹299", redirectUrl: "/product/5" },
        { id: 6, productName: "Huggies Wipes", imageUrl: "/images/products/huggies-wipes.jpg", offerText: "Starting ₹149", redirectUrl: "/product/6" },
        { id: 7, productName: "Newborn Diapers", imageUrl: "/images/products/newborn-diapers.jpg", offerText: "Starting ₹399", redirectUrl: "/product/7" },
        { id: 8, productName: "Baby Rash Cream", imageUrl: "/images/products/rash-cream.jpg", offerText: "Starting ₹99", redirectUrl: "/product/8" }
      ]
    },
    {
      id: 3,
      cardText: "Up to 50% off | Ride ons",
      categoryLink: "/products/filter?categoryId=19&maxPrice=5000",
      items: [
        { id: 9, productName: "Kids Bike", imageUrl: "/images/products/kids-bike.jpg", offerText: "Starting ₹1999", redirectUrl: "/product/9" },
        { id: 10, productName: "Scooter", imageUrl: "/images/products/scooter.jpg", offerText: "Starting ₹999", redirectUrl: "/product/10" },
        { id: 11, productName: "Rocking Horse", imageUrl: "/images/products/rocking-horse.jpg", offerText: "Starting ₹799", redirectUrl: "/product/11" },
        { id: 12, productName: "Push Car", imageUrl: "/images/products/push-car.jpg", offerText: "Starting ₹1499", redirectUrl: "/product/12" }
      ]
    },
    {
      id: 4,
      cardText: "Starting ₹649 | RC cars",
      categoryLink: "/products/filter?categoryId=19&minPrice=649",
      items: [
        { id: 13, productName: "RC Racing Car", imageUrl: "/images/products/rc-racing.jpg", offerText: "Starting ₹649", redirectUrl: "/product/13" },
        { id: 14, productName: "Offroad RC", imageUrl: "/images/products/rc-offroad.jpg", offerText: "Starting ₹1299", redirectUrl: "/product/14" },
        { id: 15, productName: "Drone", imageUrl: "/images/products/drone.jpg", offerText: "Starting ₹2499", redirectUrl: "/product/15" },
        { id: 16, productName: "RC Truck", imageUrl: "/images/products/rc-truck.jpg", offerText: "Starting ₹899", redirectUrl: "/product/16" }
      ]
    }
  ];

  // Check login status
  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    setIsLoggedIn(!!token);
  }, []);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch banners from API
      const bannersData = await bannerService.getActiveBanners();
      setBanners(bannersData || []);
      
      // Use static product cards for now (until backend API is ready)
      // You can replace this with API call when available
      setProductCards(staticProductCards);
      
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  // Auto-play functionality
  useEffect(() => {
    let interval;
    if (isAutoPlaying && banners.length > 1) {
      interval = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % banners.length);
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [isAutoPlaying, banners.length]);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % banners.length);
    resetAutoPlay();
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + banners.length) % banners.length);
    resetAutoPlay();
  };

  const resetAutoPlay = () => {
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const handleImageClick = (e, banner) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickY = e.clientY - rect.top;
    const imageHeight = rect.height;
    const clickPercentage = (clickY / imageHeight) * 100;
    
    if (clickPercentage <= 30 && banner.redirectUrl) {
      navigate(banner.redirectUrl);
    }
  };

  const handleProductClick = (e, product) => {
    e.stopPropagation();
    if (product.redirectUrl) {
      navigate(product.redirectUrl);
    }
  };

  const handleCardTextClick = (e, card) => {
    e.stopPropagation();
    if (card.categoryLink) {
      navigate(card.categoryLink);
    }
  };

  const handleSignInClick = () => {
    navigate('/login');
  };

  if (loading) {
    return <div className={styles.carouselLoading}>Loading amazing deals...</div>;
  }

  if (error && banners.length === 0 && productCards.length === 0) {
    return <div className={styles.carouselError}>{error}</div>;
  }

  if (banners.length === 0) {
    return null;
  }

  const currentBanner = banners[currentIndex];
  const fullImageUrl = `http://localhost:8080${currentBanner.imageUrl}`;

  // Calculate how many product cards to show (max 3 if sign in card shown, else 4)
  const maxCards = isLoggedIn ? 4 : 3;
  const displayedCards = productCards.slice(0, maxCards);

  return (
    <div 
      className={styles.heroCarousel}
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      {/* Main Banner Image */}
      <div className={styles.carouselSlide}>
        <div 
          className={styles.imageClickZone}
          onClick={(e) => handleImageClick(e, currentBanner)}
        >
          <img 
            src={fullImageUrl}
            alt={currentBanner.title || 'Banner'}
            className={styles.carouselImage}
            loading="eager"
          />
        </div>
      </div>

      {/* Bottom Cards Section */}
      <div className={styles.bottomCardsContainer}>
        <div className={styles.cardsWrapper}>
          {/* Product Cards - Using static data */}
          {displayedCards.map((card) => (
            <div key={card.id} className={styles.productCard}>
              <div 
                className={styles.cardHeaderText}
                onClick={(e) => handleCardTextClick(e, card)}
              >
                {card.cardText}
              </div>
              <div className={styles.cardImagesGrid}>
                {card.items && card.items.slice(0, 4).map((product) => (
                  <div 
                    key={product.id} 
                    className={styles.cardImageItem}
                    onClick={(e) => handleProductClick(e, product)}
                  >
                    <img 
                      src={`http://localhost:8080${product.imageUrl}`}
                      alt={product.productName}
                      className={styles.cardProductImage}
                      onError={(e) => {
                        e.target.src = 'https://via.placeholder.com/150x150/f0f0f0/999?text=Product';
                      }}
                    />
                    <div className={styles.productOfferText}>{product.offerText}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Sign In Card - ONLY SHOW WHEN NOT LOGGED IN */}
          {!isLoggedIn && (
            <div className={styles.signInCard}>
              <div className={styles.signInContent}>
                <div className={styles.signInIcon}>🔐</div>
                <h3 className={styles.signInTitle}>Sign in for your best experience</h3>
                <p className={styles.signInDescription}>
                  Get personalized recommendations, track orders, and enjoy exclusive offers
                </p>
                <button className={styles.signInButton} onClick={handleSignInClick}>
                  Sign in securely →
                </button>
              </div>
              <div className={styles.signInFooter}>
                <span>New customer? </span>
                <button className={styles.createAccountLink} onClick={() => navigate('/signup')}>
                  Start here
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Navigation Arrows */}
      {banners.length > 1 && (
        <>
          <button className={`${styles.arrow} ${styles.prev}`} onClick={prevSlide}>
            ❮
          </button>
          <button className={`${styles.arrow} ${styles.next}`} onClick={nextSlide}>
            ❯
          </button>
        </>
      )}

      {/* Dots */}
      {banners.length > 1 && (
        <div className={styles.dots}>
          {banners.map((_, index) => (
            <button
              key={index}
              className={`${styles.dot} ${index === currentIndex ? styles.active : ''}`}
              onClick={() => {
                setCurrentIndex(index);
                resetAutoPlay();
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default HeroSection;